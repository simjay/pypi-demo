from pyfiglet import Figlet


def greet():
    print(Figlet(font="slant").renderText("HELLO CLOUDOPEN !"))